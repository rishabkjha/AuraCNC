package com.auracnc.app.data

import java.io.File

enum class ConnectionMode {
    LOCAL_AP,
    REMOTE_CLOUD
}

data class EdgeDevice(
    val id: String,
    val name: String,
    val address: String,
    val requiresPassword: Boolean = true
)

data class RoutingConfig(
    val mode: ConnectionMode,
    val targetDeviceId: String,
    val targetAddress: String,
    val securityToken: String = ""
)

enum class RelayStatus {
    IDLE,
    LISTENING,
    CAPTURE_RECEIVED,
    FORWARDING,
    COMPLETED,
    FAILURE
}

data class CaptureMetadata(
    val millimetersPerPixel: Float,
    val tapX: Int,
    val tapY: Int
)

data class CapturePackage(
    val imageFile: File,
    val metadata: CaptureMetadata
)