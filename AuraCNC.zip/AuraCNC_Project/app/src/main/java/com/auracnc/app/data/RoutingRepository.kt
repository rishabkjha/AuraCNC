package com.auracnc.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "routing_preferences")

class RoutingRepository(private val context: Context) {
    companion object {
        private val KEY_MODE = stringPreferencesKey("routing_mode")
        private val KEY_DEVICE_ID = stringPreferencesKey("device_id")
        private val KEY_ADDRESS = stringPreferencesKey("device_address")
        private val KEY_TOKEN = stringPreferencesKey("security_token")
    }

    val currentRouting: Flow<RoutingConfig?> = context.dataStore.data.map { prefs ->
        val modeStr = prefs[KEY_MODE] ?: return@map null
        RoutingConfig(
            mode = ConnectionMode.valueOf(modeStr),
            targetDeviceId = prefs[KEY_DEVICE_ID] ?: "",
            targetAddress = prefs[KEY_ADDRESS] ?: "",
            securityToken = prefs[KEY_TOKEN] ?: ""
        )
    }

    suspend fun saveRouting(config: RoutingConfig) {
        context.dataStore.edit { prefs ->
            prefs[KEY_MODE] = config.mode.name
            prefs[KEY_DEVICE_ID] = config.targetDeviceId
            prefs[KEY_ADDRESS] = config.targetAddress
            prefs[KEY_TOKEN] = config.securityToken
        }
    }
}