package com.auracnc.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.auracnc.app.data.*
import com.auracnc.app.network.WifiScanRepository
import com.auracnc.app.ui.*
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val appScope = MainScope()
    private val wifiRepo = WifiScanRepository()
    private lateinit var routingRepo: RoutingRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        routingRepo = RoutingRepository(applicationContext)

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppNavigationCoordinator()
                }
            }
        }
    }

    @Composable
    fun AppNavigationCoordinator() {
        var appStage by remember { mutableStateOf("MODE_SELECT") }
        var activeMode by remember { mutableStateOf<ConnectionMode?>(null) }
        var scannedDevices by remember { mutableStateOf<List<EdgeDevice>>(emptyList()) }

        when (appStage) {
            // Inside MainActivity.kt -> AppNavigationCoordinator() -> when(appStage)
            // Inside MainActivity.kt -> AppNavigationCoordinator() -> when(appStage) -> "MODE_SELECT"
            "MODE_SELECT" -> {
                ModeSelectionScreen(onModeSelected = { mode ->
                    activeMode = mode
                    appScope.launch {
                        scannedDevices = when (mode) {
                            ConnectionMode.LOCAL_AP -> wifiRepo.scanForEdgeDevices()
                            ConnectionMode.REMOTE_CLOUD -> listOf(
                                EdgeDevice(
                                    id = "auracnc_production",
                                    name = "AuraCNC Cloud Console",
                                    address = "https://auracnc-a71b3-default-rtdb.asia-southeast1.firebasedatabase.app",
                                    requiresPassword = false // Turn off for rapid test or keep true if you want token validation
                                )
                            )
                        }
                        appStage = "DEVICE_SELECT"
                    }
                })
            }
            "DEVICE_SELECT" -> {
                DeviceListScreen(
                    mode = activeMode ?: ConnectionMode.LOCAL_AP,
                    devices = scannedDevices,
                    onDeviceConfirmed = { device, token ->
                        appScope.launch {
                            routingRepo.saveRouting(
                                RoutingConfig(
                                    mode = activeMode !!,
                                    targetDeviceId = device.id,
                                    targetAddress = device.address,
                                    securityToken = token
                                )
                            )
                            appStage = "SCAN_INTERFACE"
                        }
                    }
                )
            }
            "SCAN_INTERFACE" -> {
                SystemBridgeControlScreen()
            }
        }
    }
}