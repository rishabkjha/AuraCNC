package com.auracnc.app.network

import com.auracnc.app.data.EdgeDevice

class WifiScanRepository {
    suspend fun scanForEdgeDevices(): List<EdgeDevice> {
        // Dynamic Network Service Discovery (NSD) will populate this live.
        return emptyList()
    }
}