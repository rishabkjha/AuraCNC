package com.auracnc.app.ui

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.auracnc.app.data.ConnectionMode
import com.auracnc.app.data.EdgeDevice
import com.auracnc.app.data.RelayStatus
import com.auracnc.app.network.CaptureRelayBus
import com.auracnc.app.network.CaptureRelayService

@Composable
fun ModeSelectionScreen(onModeSelected: (ConnectionMode) -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Select AuraCNC Communication Mode", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(bottom = 32.dp))

        Button(onClick = { onModeSelected(ConnectionMode.LOCAL_AP) }, modifier = Modifier.fillMaxWidth().padding(8.dp)) {
            Text("Local Wi-Fi (Access Point Mode)")
        }
        Button(onClick = { onModeSelected(ConnectionMode.REMOTE_CLOUD) }, modifier = Modifier.fillMaxWidth().padding(8.dp)) {
            Text("Remote Access Mode (Firebase Cloud)")
        }
    }
}

@Composable
fun DeviceListScreen(
    mode: ConnectionMode,
    devices: List<EdgeDevice>,
    onDeviceConfirmed: (EdgeDevice, String) -> Unit
) {
    var selectedDevice by remember { mutableStateOf<EdgeDevice?>(null) }
    var securityToken by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
        Text("Target Hardware Nodes - ${mode.name}", style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(bottom = 16.dp))

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(devices) { device ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { selectedDevice = device },
                    colors = CardDefaults.cardColors(containerColor = if (selectedDevice?.id == device.id) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(device.name, style = MaterialTheme.typography.bodyLarge)
                        Text("Address/Port: ${device.address}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        selectedDevice?.let { device ->
            if (device.requiresPassword) {
                OutlinedTextField(
                    value = securityToken,
                    onValueChange = { securityToken = it },
                    label = { Text("Authentication Key / Password") },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                )
            }
            Button(
                onClick = { onDeviceConfirmed(device, securityToken) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Lock Route & Access Scan Engine")
            }
        }
    }
}

@Composable
fun SystemBridgeControlScreen() {
    val context = LocalContext.current
    val processingState by CaptureRelayBus.state.collectAsState()
    val failureContext by CaptureRelayBus.lastErrorMessage.collectAsState()

    DisposableEffect(Unit) {
        val intent = Intent(context, CaptureRelayService::class.java)
        context.startService(intent)
        onDispose {
            context.stopService(intent)
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Spatial Compute Interface", style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(24.dp))

        Card(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Active Route State:")
                Text(processingState.name, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)

                failureContext?.let {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Error Info: $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = { launchExternalSpatialEngine(context) },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            Text("Initialize Hello AR Scanner")
        }
    }
}

private fun launchExternalSpatialEngine(context: Context) {
    val pm = context.packageManager
    val launchIntent = pm.getLaunchIntentForPackage("com.google.ar.core.examples.kotlin.helloar")
    if (launchIntent != null) {
        context.startActivity(launchIntent)
    } else {
        CaptureRelayBus.updateState(RelayStatus.FAILURE, "Hello AR App installation package not found")
    }
}