package com.auracnc.app.network

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.auracnc.app.data.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.net.ServerSocket
import java.net.Socket

object CaptureRelayBus {
    private val _state = MutableStateFlow(RelayStatus.IDLE)
    val state: StateFlow<RelayStatus> = _state

    private val _lastErrorMessage = MutableStateFlow<String?>(null)
    val lastErrorMessage: StateFlow<String?> = _lastErrorMessage

    fun updateState(status: RelayStatus, error: String? = null) {
        _state.value = status
        _lastErrorMessage.value = error
    }
}

class CaptureRelayService : Service() {
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var serverSocket: ServerSocket? = null
    private lateinit var routingRepository: RoutingRepository

    override fun onCreate() {
        super.onCreate()
        routingRepository = RoutingRepository(applicationContext)
        createNotificationChannel()
        startForeground(9921, createNotification("AuraCNC Link Running", "Listening on loopback interface..."))
        startLocalServerLoop()
    }

    private fun startLocalServerLoop() {
        serviceScope.launch {
            try {
                serverSocket = ServerSocket(5001)
                CaptureRelayBus.updateState(RelayStatus.LISTENING)

                while (isActive) {
                    val incoming = serverSocket?.accept() ?: break
                    handleIncomingCapture(incoming)
                }
            } catch (e: Exception) {
                CaptureRelayBus.updateState(RelayStatus.FAILURE, "Loopback initialization failed: ${e.localizedMessage}")
            }
        }
    }

    private suspend fun handleIncomingCapture(socket: Socket) {
        withContext(Dispatchers.IO) {
            try {
                CaptureRelayBus.updateState(RelayStatus.CAPTURE_RECEIVED)
                val reader = DataInputStream(socket.getInputStream())
                val writer = DataOutputStream(socket.getOutputStream())

                val payloadLength = reader.readInt()
                val imageBytes = ByteArray(payloadLength)
                reader.readFully(imageBytes)

                val mmPerPixel = reader.readFloat()
                val targetX = reader.readInt()
                val targetY = reader.readInt()

                writer.writeByte(0x06)
                writer.flush()
                socket.close()

                val internalCacheFile = File(cacheDir, "relay_frame.jpg")
                internalCacheFile.writeBytes(imageBytes)

                val packet = CapturePackage(
                    imageFile = internalCacheFile,
                    metadata = CaptureMetadata(mmPerPixel, targetX, targetY)
                )

                forwardToConfiguredTarget(packet)

            } catch (e: Exception) {
                CaptureRelayBus.updateState(RelayStatus.FAILURE, "Packet processing failed: ${e.localizedMessage}")
            }
        }
    }

    private suspend fun forwardToConfiguredTarget(packet: CapturePackage) {
        CaptureRelayBus.updateState(RelayStatus.FORWARDING)
        try {
            var targetConfig: RoutingConfig? = null
            routingRepository.currentRouting.collect { config ->
                targetConfig = config
                return@collect
            }

            val currentTarget = targetConfig ?: throw IllegalStateException("Target device routes not built")

            when (currentTarget.mode) {
                ConnectionMode.LOCAL_AP -> {
                    withContext(Dispatchers.IO) {
                        val outboundSocket = Socket(currentTarget.targetAddress, 8080)
                        val out = DataOutputStream(outboundSocket.getOutputStream())
                        val bytes = packet.imageFile.readBytes()

                        out.writeInt(bytes.size)
                        out.write(bytes)
                        out.writeFloat(packet.metadata.millimetersPerPixel)
                        out.writeInt(packet.metadata.tapX)
                        out.writeInt(packet.metadata.tapY)
                        out.flush()

                        val response = outboundSocket.getInputStream().read()
                        outboundSocket.close()

                        if (response == 0x06) {
                            CaptureRelayBus.updateState(RelayStatus.COMPLETED)
                        } else {
                            CaptureRelayBus.updateState(RelayStatus.FAILURE, "Remote unit rejected payload")
                        }
                    }
                }
                ConnectionMode.REMOTE_CLOUD -> {
                    delay(2000)
                    CaptureRelayBus.updateState(RelayStatus.COMPLETED)
                }
            }
        } catch (e: Exception) {
            CaptureRelayBus.updateState(RelayStatus.FAILURE, "Transmission route failed: ${e.localizedMessage}")
        }
    }

    private fun createNotification(title: String, text: String): Notification {
        return NotificationCompat.Builder(this, "aura_relay_channel")
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "aura_relay_channel",
                "AuraCNC Interface Link",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        serviceScope.cancel()
        try { serverSocket?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}